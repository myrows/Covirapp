package com.example.covirapp.common

class Constantes {

    companion object {
        const val API_BASE_URL = "http://10.0.2.2:9000"
        const val SHARED_PREFS_FILE: String = "SHARED_PREFERENCES_FILE"
        const val TIMEOUT_INMILIS = 30000L
    }
}