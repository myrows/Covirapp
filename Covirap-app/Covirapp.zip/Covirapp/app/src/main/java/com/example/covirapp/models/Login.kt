package com.example.covirapp.models

class Login ( val grant_type : String, val username : String, val password : String ) {

}
